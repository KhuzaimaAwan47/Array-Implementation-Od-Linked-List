#include"find.h"
#include"insert.h"
#include"is empty.h"
#include"is full.h"
#include"Array list.h"
#include"remove.h"
#include"replace.h"
#include"show structure.h"


int main() {
	int size, num, rem, index, elem, find;
	cout << "Enter Size of Array : ";
	cin >> size;
	List obj(size);
	cout << endl << "Enter Values: " << endl;
	for (int i = 0; i < size; i++) {
		cin >> num;
		obj.insert(num);
	}
	cout << endl << "Your Given Values Are: " << endl;
	obj.showStructure();
	cout << "\nHow Many Numbers You want to Remove From Array?: ";
	cin >> rem;
	for (int i = 0; i < rem; i++){
		obj.remove();
	}
	cout << "Numbers Removed Successfully....\n ";
	cout << endl << "After Removing The Remaining Numbers are: " << endl;
	obj.showStructure();
	cout << "\nAre you want to replace a number?   (tell me its Position): ";
	cin >> index;
	cout << "\nPlease Enter a new Number: ";
	cin >> elem;
	cout << endl << "Now Your Numbers Are: " << endl;

	obj.replace(elem, index);
	obj.showStructure();
	cout << "\nAre You want to find a number? :    ";
	cin >> find;
	if (obj.find(find))
		cout << endl << "Number Found Successfuly....\n";
	else
		cout << endl << "Oops Number Not found....\n";
	cout<<"_K_H_U_Z_A_I_M_A__A_W_A_N_47__" << endl;
	return 0;
}