#include "Array list.h"

bool List::isEmpty()
{
	if (length == 0)
		return true;
	else
		return false;
}