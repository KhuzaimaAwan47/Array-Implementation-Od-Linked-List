#include "Array list.h"
#include<iostream>
using namespace std;

int List::remove()
{
	if (!isEmpty())
	{
		length--;
		return elements[length];
	}
	else
	{
		cout << "Remove: Cannot remove the item. List is empty\n";
	}
}