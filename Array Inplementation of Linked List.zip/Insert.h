#include "Array list.h"
#include<iostream>
using namespace std;

List::List(int maxsize){

	size = maxsize;
	elements = new int[size];
	length = 0;
}
List::~List(){
	delete[]elements;
}
void List::insert(int newDataItem){
	if (!isFull())
	{
		elements[length] = newDataItem;
		length++;
	}
	else
	{
		cout << "Insert: Cannot insert more items. List is full\n";
	}
}

