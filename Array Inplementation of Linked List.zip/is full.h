#include "Array list.h"


bool List::isFull()
{
	if (length < size)
		return false;
	else
		return true;
}