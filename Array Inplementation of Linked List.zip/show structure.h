#include "Array list.h"
#include<iostream>
using namespace std;


void List::showStructure()
{
	if (!isEmpty())
	{
		for (int i = 0; i < length; i++)
		{
			cout << "Number:  " << elements[i] << endl;
		}
	}
	else
	{
		cout << "Display: No items to be displayed. List is empty\n";
	}
}