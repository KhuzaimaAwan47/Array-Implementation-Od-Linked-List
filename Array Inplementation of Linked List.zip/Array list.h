#include<iostream>
#ifndef List_h
#define List_h

class List {
private:
	int* elements;
	int size;
	int length;

public:
	List(int maxsize);
	~List();
	void insert(int newDataItem);
	void showStructure();
	int remove();
	void replace(int newDataItem, int position);
	bool find(int searchDataItem);
	bool isEmpty();
	bool isFull();
};
#endif